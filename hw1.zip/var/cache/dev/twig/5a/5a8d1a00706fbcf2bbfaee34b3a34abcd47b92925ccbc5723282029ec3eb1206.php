<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/index.html.twig */
class __TwigTemplate_8b6759ba2909d2737085a23bd08af2b83a99f51f5a35bd8cb5266f3532f70531 extends \Twig\Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "home/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Projektai";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "    <ul class=\"list-group m-4\">
        <li class=\"list-group-item list-group-item-info\">Studentai</li>
        ";
        // line 8
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["students"]) || array_key_exists("students", $context) ? $context["students"] : (function () { throw new RuntimeError('Variable "students" does not exist.', 8, $this->source); })()));
        foreach ($context['_seq'] as $context["name"] => $context["data"]) {
            // line 9
            echo "            <li class=\"list-group-item\">
                <a href=\"";
            // line 10
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("student", ["name" => $context["name"], "project" => twig_get_attribute($this->env, $this->source, $context["data"], "project", [], "any", false, false, false, 10)]), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, $context["name"], "html", null, true);
            echo "</a>
                (
                <span class=\"badge\">";
            // line 12
            if ((twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "mentors", [], "any", false, false, false, 12)) > 1)) {
                echo "Mentoriai";
            } else {
                echo "Mentorius";
            }
            echo "</span> ";
            echo twig_escape_filter($this->env, twig_join_filter(twig_get_attribute($this->env, $this->source, $context["data"], "mentors", [], "any", false, false, false, 12), ", "), "html", null, true);
            echo "
                )
            </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['name'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 16
        echo "    </ul>

    <div class=\"m-4\">
        <form action=\"";
        // line 19
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("student");
        echo "\" method=\"get\">
            <div class=\"input-group\">
                <input name=\"name\" type=\"text\" class=\"form-control\" placeholder=\"Studentas\"/>
            </div>
            <div class=\"input-group\">
                <input name=\"project\" type=\"text\" class=\"form-control\" placeholder=\"Projektas\"/>
            </div>
            <button type=\"submit\" class=\"btn btn-success\">Sužinoti vertinimą</button>
        </form>
    </div>

    <ul class=\"list-group m-4\">
        <li class=\"list-group-item list-group-item-info\">Projektai</li>
        ";
        // line 32
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["projects"]) || array_key_exists("projects", $context) ? $context["projects"] : (function () { throw new RuntimeError('Variable "projects" does not exist.', 32, $this->source); })()));
        foreach ($context['_seq'] as $context["name"] => $context["data"]) {
            // line 33
            echo "            <li class=\"list-group-item\">
                <h3>";
            // line 34
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["data"], "name", [], "any", false, false, false, 34), "html", null, true);
            echo "</h3>
                <div class=\"panel panel-default\">
                    <div>
                        <a target=\"_blank\" href=\"https://github.com/nfqakademija/";
            // line 37
            echo twig_escape_filter($this->env, twig_urlencode_filter($context["name"]), "html", null, true);
            echo "\">github.com/nfqakademija/";
            echo twig_escape_filter($this->env, $context["name"]);
            echo "</a>
                        <span class=\"badge\">GitHub</span>
                    </div>
                    <div>
                        <a target=\"_blank\" href=\"http://";
            // line 41
            echo twig_escape_filter($this->env, twig_urlencode_filter($context["name"]), "html", null, true);
            echo ".projektai.nfqakademija.lt/\">";
            echo twig_escape_filter($this->env, $context["name"], "html", null, true);
            echo ".projektai.nfqakademija.lt/</a>
                        <span class=\"badge\">Web</span>
                    </div>
                    <div>
                        <pre>ssh ";
            // line 45
            echo twig_escape_filter($this->env, $context["name"], "html", null, true);
            echo "@deploy.nfqakademija.lt -p 2222</pre>
                    </div>
                </div>
            </li>
        ";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['name'], $context['data'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 50
        echo "    </ul>

    <div class=\"m-4\">
        <a class=\"text-light\" href=\"students.json\">Duomenų failas</a>
    </div>
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  170 => 50,  159 => 45,  150 => 41,  141 => 37,  135 => 34,  132 => 33,  128 => 32,  112 => 19,  107 => 16,  91 => 12,  84 => 10,  81 => 9,  77 => 8,  73 => 6,  66 => 5,  53 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Projektai{% endblock %}

{% block body %}
    <ul class=\"list-group m-4\">
        <li class=\"list-group-item list-group-item-info\">Studentai</li>
        {% for name, data in students %}
            <li class=\"list-group-item\">
                <a href=\"{{ path('student', {'name': name, 'project': data.project}) }}\">{{ name }}</a>
                (
                <span class=\"badge\">{% if data.mentors|length > 1 %}Mentoriai{% else %}Mentorius{% endif %}</span> {{ data.mentors|join(', ') }}
                )
            </li>
        {% endfor %}
    </ul>

    <div class=\"m-4\">
        <form action=\"{{ path('student') }}\" method=\"get\">
            <div class=\"input-group\">
                <input name=\"name\" type=\"text\" class=\"form-control\" placeholder=\"Studentas\"/>
            </div>
            <div class=\"input-group\">
                <input name=\"project\" type=\"text\" class=\"form-control\" placeholder=\"Projektas\"/>
            </div>
            <button type=\"submit\" class=\"btn btn-success\">Sužinoti vertinimą</button>
        </form>
    </div>

    <ul class=\"list-group m-4\">
        <li class=\"list-group-item list-group-item-info\">Projektai</li>
        {% for name, data in projects %}
            <li class=\"list-group-item\">
                <h3>{{ data.name}}</h3>
                <div class=\"panel panel-default\">
                    <div>
                        <a target=\"_blank\" href=\"https://github.com/nfqakademija/{{ name|url_encode }}\">github.com/nfqakademija/{{ name|escape }}</a>
                        <span class=\"badge\">GitHub</span>
                    </div>
                    <div>
                        <a target=\"_blank\" href=\"http://{{ name|url_encode }}.projektai.nfqakademija.lt/\">{{ name }}.projektai.nfqakademija.lt/</a>
                        <span class=\"badge\">Web</span>
                    </div>
                    <div>
                        <pre>ssh {{ name }}@deploy.nfqakademija.lt -p 2222</pre>
                    </div>
                </div>
            </li>
        {% endfor %}
    </ul>

    <div class=\"m-4\">
        <a class=\"text-light\" href=\"students.json\">Duomenų failas</a>
    </div>
{% endblock %}
", "home/index.html.twig", "/code/templates/home/index.html.twig");
    }
}
